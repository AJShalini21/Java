export interface skill
{

    SkillId:number;
    SkillName:string;
}